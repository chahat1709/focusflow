@echo off
title Focus Flow v1.1
cd /d "%~dp0"

:: Check Python
python --version >nul 2>&1
if errorlevel 1 (
    echo ERROR: Python not found!
    echo.
    echo Please install Python 3.12 from: https://www.python.org/downloads/
    echo Make sure to check "Add Python to PATH" during installation.
    pause
    exit
)

:: Install dependencies silently
echo Installing dependencies (one-time setup)...
pip install -q flask flask-cors pylsl bleak python-osc numpy scipy pygame

:: Launch app
cls
echo ========================================
echo   Focus Flow v1.1 - Professional Edition
echo ========================================
echo.
echo Starting application...
echo Browser will open automatically.
echo.
echo DO NOT CLOSE THIS WINDOW!
echo.
python start_app_monolith.py
pause
